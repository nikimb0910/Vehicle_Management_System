#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

// WiFi Configuration
const char* ssid = "OnePlus";
const char* password = "00000111";

// MQTT Broker Configuration
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;
const char* dataTopic = "ev/battery/yourUniqueId123";
const char* statusTopic = "ev/battery/status";

WiFiClient espClient;
PubSubClient client(espClient);

// Hardware Serial 2 (UART2) Configuration
// Connect STM32 PA0 (TX) -> ESP32 GPIO 16 (RX2)
// Connect STM32 PA1 (RX) -> ESP32 GPIO 17 (TX2)
#define RXD2 16
#define TXD2 17

// System Telemetry Variables
float soc = 0.0, soh = 0.0, voltage = 0.0, current = 0.0, power = 0.0, temperature = 0.0;
int smoke = 0, fan = 0, buzzer = 0, safe = 0;
int currentFault = 0, tempFault = 0, smokeFault = 0;
unsigned long lastPublish = 0;

void setupWiFi()
{
  Serial.print("Connecting to WiFi...");
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected successfully!");
}

void reconnectMQTT()
{
  while (!client.connected())
  {
    Serial.print("Connecting MQTT...");

    if (client.connect(
            "ESP32_EV_BMS_NODE",
            NULL,
            NULL,
            statusTopic,
            1,
            true,
            "offline"))
    {
      Serial.println("Connected");

      client.publish(statusTopic, "online", true);
    }
    else
    {
      Serial.print("Failed rc=");
      Serial.println(client.state());

      delay(2000);
    }
  }
}

void setup()
{
  Serial.begin(115200);

  // Initialize UART2 for STM32 Communication
  Serial2.begin(115200, SERIAL_8N1, RXD2, TXD2);

  setupWiFi();
  client.setServer(mqtt_server, mqtt_port);
}

void loop()
{
  if (!client.connected())
    reconnectMQTT();

  client.loop();

  if (Serial2.available() > 0)
  {
    String line = Serial2.readStringUntil('\n');
    line.trim();

    // Debug raw incoming line
    Serial.print("Raw UART Line: ");
    Serial.println(line);

    int values = sscanf(line.c_str(),
                        "%f,%f,%f,%f,%f,%f,%d,%d,%d,%d,%d,%d,%d",
                        &soc, &soh, &voltage, &current, &power, &temperature,
                        &smoke, &fan, &buzzer, &safe,
                        &currentFault, &tempFault, &smokeFault);

    if (values == 13)
    {
      // Use JsonDocument for modern ArduinoJson (or StaticJsonDocument<512> for v6)
      StaticJsonDocument<512> doc;

      doc["soc"] = soc;
      doc["soh"] = soh;
      doc["voltage"] = voltage;
      doc["current"] = current;
      doc["power"] = power;
      doc["temperature"] = temperature;

      doc["smoke"] = smoke;
      doc["fan"] = fan;
      doc["buzzer"] = buzzer;
      doc["safe"] = safe;

      doc["currentFault"] = currentFault;
      doc["tempFault"] = tempFault;
      doc["smokeFault"] = smokeFault;

      doc["timestamp"] = millis();

      char buffer[512];
      serializeJson(doc, buffer);

      client.publish(dataTopic, buffer);
      Serial.println("Published MQTT:");
      Serial.println(buffer);
    }
    else
    {
      Serial.println("Invalid UART Packet Format");
    }

    // Clear buffer to prevent stale frames from piling up
    while (Serial2.available() > 0) {
      Serial2.read();
    }
  }
  if (millis() - lastPublish >= 2000)
{
  lastPublish = millis();

  StaticJsonDocument<512> doc;

  doc["soc"] = soc;
  doc["soh"] = soh;
  doc["voltage"] = voltage;
  doc["current"] = current;
  doc["power"] = power;
  doc["temperature"] = temperature;

  doc["smoke"] = smoke;
  doc["fan"] = fan;
  doc["buzzer"] = buzzer;
  doc["safe"] = safe;

  doc["currentFault"] = currentFault;
  doc["tempFault"] = tempFault;
  doc["smokeFault"] = smokeFault;

  doc["timestamp"] = millis();

  char buffer[512];

  serializeJson(doc, buffer);

  client.publish(dataTopic, buffer);
}
}